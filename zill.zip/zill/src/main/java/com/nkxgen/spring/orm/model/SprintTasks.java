package com.nkxgen.spring.orm.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "T4_SprintTasks")
public class SprintTasks {
	@EmbeddedId
	private SprintTasksId id;

	@ManyToOne
	@JoinColumn(name = "sprn_id", insertable = false, updatable = false)
	private Sprint sprint;

	@OneToOne
	@JoinColumn(name = "task_id", insertable = false, updatable = false)
	private Task task;

	@ManyToOne
	@JoinColumn(name = "user_id", insertable = false, updatable = false)
	private User user;

	public SprintTasks(SprintTasksId id, Sprint sprint, Task task, User user) {
		this.id = id;
		this.sprint = sprint;
		this.task = task;
		this.user = user;
	}

	public SprintTasks() {
		super();
	}

	public SprintTasksId getId() {
		return id;
	}

	public void setId(SprintTasksId id) {
		this.id = id;
	}

	public Sprint getSprint() {
		return sprint;
	}

	public void setSprint(Sprint sprint) {
		this.sprint = sprint;
	}

	public void setTask(Task task) {
		this.task = task;
	}

	// Constructors, other properties, and methods

	public int getUserId() {
		return user.getUserId();
	}

	public int getTaskId() {
		return task.getTaskId();

		// Getters and setters for user and task
	}

	@Override
	public String toString() {
		return "SprintTasks [id=" + id + ", sprint=" + sprint + ", task=" + task + ", user=" + user + "]";
	}

	public void setUser(User user) {
		this.user = user;
	}

}
